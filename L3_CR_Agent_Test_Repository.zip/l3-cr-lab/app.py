"""L3 CR Lab: deliberately defective mini document portal.
Do not deploy on a public network; this is a local training application.
"""
from pathlib import Path
from datetime import datetime, timezone
import sqlite3
from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.utils import secure_filename

BASE = Path(__file__).resolve().parent
DB_PATH = BASE / 'lab.db'
UPLOAD_DIR = BASE / 'uploads'
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
# BUG L3CR-101: 1 MiB application request cap rejects ordinary larger uploads.
app.config['MAX_CONTENT_LENGTH'] = 1 * 1024 * 1024


def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect_db() as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            size INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )''')


@app.get('/')
def home():
    return render_template('index.html')


@app.get('/api/documents')
def list_documents():
    query = request.args.get('q', '')
    with connect_db() as conn:
        # BUG L3CR-103: case-sensitive search misses documents with different casing.
        rows = conn.execute('SELECT * FROM documents ORDER BY id DESC').fetchall()
    docs = [dict(r) for r in rows if query in r['name']]
    return jsonify({'documents': docs, 'count': len(docs)})


@app.post('/api/upload')
def upload():
    file = request.files.get('file')
    if file is None or not file.filename:
        return jsonify({'error': 'Select a file first'}), 400
    filename = secure_filename(file.filename)
    if not filename:
        return jsonify({'error': 'Invalid filename'}), 400
    # BUG L3CR-104: same-name uploads overwrite original file on disk.
    file.save(UPLOAD_DIR / filename)
    size = (UPLOAD_DIR / filename).stat().st_size
    with connect_db() as conn:
        cur = conn.execute(
            'INSERT INTO documents (name, size, created_at) VALUES (?, ?, ?)',
            (filename, size, datetime.now(timezone.utc).isoformat()))
        doc_id = cur.lastrowid
    return jsonify({'message': 'Uploaded', 'document': {'id': doc_id, 'name': filename, 'size': size}}), 201


@app.get('/api/documents/<int:document_id>/download')
def download(document_id):
    with connect_db() as conn:
        row = conn.execute('SELECT name FROM documents WHERE id = ?', (document_id,)).fetchone()
    if row is None:
        return jsonify({'error': 'Document not found'}), 404
    return send_from_directory(UPLOAD_DIR, row['name'], as_attachment=True)


@app.delete('/api/documents/<int:document_id>')
def delete_document(document_id):
    with connect_db() as conn:
        row = conn.execute('SELECT name FROM documents WHERE id = ?', (document_id,)).fetchone()
        if not row:
            return jsonify({'error': 'Document not found'}), 404
        conn.execute('DELETE FROM documents WHERE id = ?', (document_id,))
    # BUG L3CR-105: delete removes DB row but leaves orphaned file on disk.
    return jsonify({'message': 'Deleted'})


@app.errorhandler(413)
def too_large(error):
    return jsonify({'error': 'Upload exceeds server limit'}), 413


init_db()

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=False)

"""Intended to FAIL before the L3 agent repairs the seeded defects."""
from io import BytesIO
from pathlib import Path
import app as app_module


def upload(client, data, name):
    return client.post('/api/upload', data={'file': (BytesIO(data), name)})


def test_L3CR_101_large_upload_should_succeed(client):
    assert upload(client, b'x' * (2 * 1024 * 1024), 'large.bin').status_code == 201


def test_L3CR_103_search_case_insensitive(client):
    assert upload(client, b'test', 'QuarterlyReport.txt').status_code == 201
    assert client.get('/api/documents?q=quarterly').json['count'] == 1


def test_L3CR_104_same_filename_must_preserve_both_files(client):
    a = upload(client, b'first', 'report.txt').json['document']['id']
    b = upload(client, b'second', 'report.txt').json['document']['id']
    assert client.get(f'/api/documents/{a}/download').data == b'first'
    assert client.get(f'/api/documents/{b}/download').data == b'second'


def test_L3CR_105_delete_must_remove_stored_file(client):
    r = upload(client, b'private file', 'obsolete.txt')
    doc_id = r.json['document']['id']
    assert any(app_module.UPLOAD_DIR.iterdir())
    client.delete(f'/api/documents/{doc_id}')
    assert list(app_module.UPLOAD_DIR.iterdir()) == []


def test_L3CR_102_no_excessive_polling():
    js = (Path(__file__).resolve().parents[1] / 'static' / 'app.js').read_text()
    assert 'setInterval(loadDocuments, 650)' not in js

from io import BytesIO

def test_home_renders(client):
    r = client.get('/')
    assert r.status_code == 200
    assert b'Document Portal' in r.data

def test_small_upload_and_list(client):
    r = client.post('/api/upload', data={'file': (BytesIO(b'hello'), 'note.txt')})
    assert r.status_code == 201
    listing = client.get('/api/documents').json
    assert listing['count'] == 1
    assert listing['documents'][0]['name'] == 'note.txt'

def test_delete_database_row(client):
    r = client.post('/api/upload', data={'file': (BytesIO(b'hello'), 'note.txt')})
    doc_id = r.json['document']['id']
    assert client.delete(f'/api/documents/{doc_id}').status_code == 200
    assert client.get('/api/documents').json['count'] == 0

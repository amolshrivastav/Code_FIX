import pytest
import app as app_module

@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(app_module, 'DB_PATH', tmp_path / 'test.db')
    monkeypatch.setattr(app_module, 'UPLOAD_DIR', tmp_path / 'uploads')
    app_module.UPLOAD_DIR.mkdir()
    app_module.init_db()
    app_module.app.config.update(TESTING=True)
    return app_module.app.test_client()

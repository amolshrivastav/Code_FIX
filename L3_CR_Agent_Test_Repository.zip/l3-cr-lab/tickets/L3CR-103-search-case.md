# L3CR-103 — Search fails when capitalization differs
**Type:** Bug | **Priority:** Medium | **Component:** Search API

## Steps
1. Upload `QuarterlyReport.txt`.
2. Search `quarterly`.
3. UI displays `No documents found`.

## Expected
Case-insensitive substring matches; `quarterly` matches `QuarterlyReport.txt`.

## Acceptance criteria
- Search is case-insensitive.
- Empty query returns all documents.
- Search does not break special characters.
- Existing list and download operations still work.

## Regression test
`pytest -q tests/test_ticket_regressions.py -k L3CR_103`

# L3CR-104 — Second upload overwrites earlier file with same name
**Type:** Bug | **Priority:** High | **Component:** Upload + Download + Persistence

## Steps
1. Upload `report.txt` containing `first`.
2. Upload another `report.txt` containing `second`.
3. Download both rows.

## Actual
Both downloaded files contain `second` because the original bytes were overwritten.

## Expected
Both document records preserve and download their respective original bytes.

## Acceptance criteria
- Unique internal storage names/paths per upload, independent of display filename.
- No data loss for repeated names.
- Download retrieves correct bytes for each document ID.
- Appropriate schema changes/migration handling if necessary.
- No path traversal via malicious filenames.

## Regression test
`pytest -q tests/test_ticket_regressions.py -k L3CR_104`

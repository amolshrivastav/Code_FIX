# L3CR-105 — Deleting document leaves orphaned file on server
**Type:** Bug | **Priority:** Medium | **Component:** Delete API + Storage

## Steps
1. Upload `obsolete.txt`.
2. Delete it using the UI.
3. Inspect `uploads/` directory.

## Actual
The database row is deleted, but the file still consumes disk space.

## Expected
The file and document record are both removed safely.

## Acceptance criteria
- Deletion removes associated data and stored file.
- Deleting a missing ID still returns 404.
- Deletion of one document never deletes another document's bytes (consider same-name upload ticket).
- Consistent behavior for file-system failures (report appropriately).

## Regression test
`pytest -q tests/test_ticket_regressions.py -k L3CR_105`

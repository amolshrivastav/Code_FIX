# L3CR-102 — Document list flickers continuously
**Type:** Bug | **Priority:** Medium | **Component:** Frontend document list

## User story
As a portal user, I want the document list to remain stable while I read or interact with it.

## Reproduction
1. Open the portal and upload 2–3 sample documents.
2. Observe the list and its update timestamp over several seconds.
3. Inspect Network tab and DOM updates; API calls and full-list replacements occur about every 650 ms.

## Expected vs actual
**Expected:** Documents refresh after meaningful actions (upload, delete, search) or via a deliberately controlled refresh with no unnecessary redraw.
**Actual:** Repeated polling and replacing innerHTML cause visible flicker and can disrupt focus/selection.

## Acceptance criteria
- No 650 ms unconditional polling.
- No full DOM rebuild if the document data is unchanged.
- Upload, delete, and search still refresh the list promptly.
- No new JS console errors; search field keeps its focus while typing.

## Regression test
`pytest -q tests/test_ticket_regressions.py -k L3CR_102` (static guard only; manually verify in browser).

## Agent task
Determine the performance/root-cause issue in the frontend, implement a minimal robust fix, and describe manual UI verification.

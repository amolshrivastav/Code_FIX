# L3CR-101 — Upload fails for files larger than 1 MB
**Type:** Bug | **Priority:** High | **Component:** Document Upload API

## User story
As a document-portal user, I need to upload a 2 MB (or larger) sample file so I can manage ordinary files.

## Reproduction
1. Launch the portal and upload a 20 KB TXT file. Upload succeeds.
2. Upload a 2 MB `.bin` or `.txt` file.
3. Observe HTTP 413 and the message `Upload exceeds server limit`.

## Expected vs actual
**Expected:** 2 MB upload succeeds and appears in the document list; downloaded content matches the original.
**Actual:** 413; no document is created.

## Acceptance criteria
- 2 MB files upload successfully.
- Response contains HTTP 201 and a document ID.
- Downloaded bytes match the uploaded bytes.
- An explicit, documented safe maximum file size remains in place (e.g. 10 MB), with 413 above the limit.
- Existing small-file uploads still work.

## Regression test
`pytest -q tests/test_ticket_regressions.py -k L3CR_101`

## Agent task
Find the root cause, patch backend configuration/handling, add or adjust tests, and explain the risk of allowing unlimited payloads.

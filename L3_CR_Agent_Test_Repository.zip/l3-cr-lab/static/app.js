const listEl = document.getElementById('documentList');
const emptyEl = document.getElementById('emptyState');
const searchEl = document.getElementById('searchInput');
const fileInput = document.getElementById('fileInput');
const notice = document.getElementById('notice');
const uploadBtn = document.getElementById('uploadBtn');
let allDocuments = [];

function formatSize(bytes) { return bytes < 1024 ? `${bytes} B` : `${(bytes / 1024).toFixed(1)} KB`; }
function escapeHTML(s) { return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function message(text, error=false) { notice.textContent = text; notice.className = error ? 'notice error' : 'notice'; }

function renderDocuments(documents) {
  listEl.innerHTML = documents.map(d => `<div class="doc-item"><div class="doc-icon">DOC</div><div class="doc-details"><div class="doc-name" title="${escapeHTML(d.name)}">${escapeHTML(d.name)}</div><div class="doc-meta">${formatSize(d.size)} • ${new Date(d.created_at).toLocaleString()}</div></div><div class="actions"><a class="action" href="/api/documents/${d.id}/download" aria-label="Download ${escapeHTML(d.name)}">↓</a><button class="action delete" data-id="${d.id}" aria-label="Delete ${escapeHTML(d.name)}">✕</button></div></div>`).join('');
  emptyEl.style.display = documents.length ? 'none' : 'block';
  document.getElementById('docCount').textContent = String(documents.length);
}

async function loadDocuments() {
  try {
    const q = encodeURIComponent(searchEl.value);
    const res = await fetch(`/api/documents?q=${q}`);
    if (!res.ok) throw new Error('Could not load documents');
    const data = await res.json();
    allDocuments = data.documents;
    // BUG L3CR-102: clearing and rebuilding the list every 650ms makes the UI flicker
    // and interrupts keyboard/selection interaction while refreshing.
    renderDocuments(allDocuments);
    document.getElementById('updatedAt').textContent = `Refreshed ${new Date().toLocaleTimeString()}`;
  } catch(e) { message(e.message, true); }
}

fileInput.addEventListener('change', () => {
  document.getElementById('selectedFile').textContent = fileInput.files[0]?.name || 'No file selected';
});

document.getElementById('uploadForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!fileInput.files[0]) return message('Choose a file first', true);
  uploadBtn.disabled = true;
  const form = new FormData(); form.append('file', fileInput.files[0]);
  try {
    const res = await fetch('/api/upload', {method:'POST', body:form});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Upload failed');
    message(`${data.document.name} uploaded successfully`);
    fileInput.value = '';
    document.getElementById('selectedFile').textContent = 'No file selected';
    await loadDocuments();
  } catch(e) {message(e.message,true);} finally {uploadBtn.disabled=false;}
});

searchEl.addEventListener('input', loadDocuments);
listEl.addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-id]');
  if (!btn) return;
  const res = await fetch(`/api/documents/${btn.dataset.id}`, {method:'DELETE'});
  message(res.ok ? 'Document removed' : 'Could not delete document', !res.ok);
  await loadDocuments();
});

loadDocuments();
// BUG L3CR-102: excessive unconditional polling redraws the entire document list.
setInterval(loadDocuments, 650);

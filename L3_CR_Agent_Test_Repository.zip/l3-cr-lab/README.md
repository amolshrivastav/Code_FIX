# L3 CR Lab — intentionally buggy document portal

A working **Flask + HTML/CSS/JavaScript + SQLite** web application to test an L3 code-fix agent. Five real defects are deliberately seeded. No external services, authentication, or cloud account required.

## Prerequisites
- Python 3.10 or newer

## Run the UI
```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```
Open **http://127.0.0.1:5000**.

## Run tests
```bash
python -m pytest tests/test_smoke.py -q
python -m pytest tests/test_ticket_regressions.py -q
```
The smoke tests should PASS. Regression tests are intentionally written to FAIL before fixes, and should PASS after the agent fixes the corresponding tickets.

## Suggested L3 agent exercise
1. Clone/extract the original baseline and commit to a local Git repository.
2. Send **one** JIRA-style ticket from `tickets/` to your L3 CR Agent.
3. Ask it to identify root cause, modify code, update tests, and explain the patch.
4. Verify that the target regression test now passes and smoke tests remain green.
5. Reset to the baseline commit before testing a different ticket, or use separate Git branches.

## Structure
```
app.py                       Flask API, upload/download/delete/search
static/app.js                UI behavior (includes flicker defect)
static/style.css             UI styling
templates/index.html         Dashboard UI
tests/test_smoke.py          Baseline pass tests
tests/test_ticket_regressions.py  Ticket acceptance tests (initially failing)
tickets/                     JIRA-style ticket markdown files
```

## Important notes
- This is **purposefully insecure/incomplete training code**. Use only at `127.0.0.1` and with synthetic files. Do not deploy publicly.
- The upload issue is a backend request-size limit, not a browser setting.
- The flicker issue is frontend polling and repeated DOM rebuilds.
- SQLite database (`lab.db`) and uploads are generated locally on execution.
- Fixing same-name file overwrites will likely require storing a unique internal storage path/name in the database and using it in download and delete paths.
